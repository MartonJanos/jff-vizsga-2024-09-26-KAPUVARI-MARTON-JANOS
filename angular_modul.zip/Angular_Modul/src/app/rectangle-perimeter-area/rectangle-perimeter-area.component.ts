import { Component } from '@angular/core';

@Component({
  selector: 'app-rectangle-perimeter-area',
  standalone: true,
  imports: [],
  templateUrl: './rectangle-perimeter-area.component.html',
  styleUrl: './rectangle-perimeter-area.component.css'
})
export class RectanglePerimeterAreaComponent {

}

function RectanglePerimeterAreaCounter(a:number,b:number):[number, number] {
  let rectanglePerimeter:number = 2 * (a + b);
  let rectangleArea:number = a * b;
  return [rectanglePerimeter, rectangleArea];
}