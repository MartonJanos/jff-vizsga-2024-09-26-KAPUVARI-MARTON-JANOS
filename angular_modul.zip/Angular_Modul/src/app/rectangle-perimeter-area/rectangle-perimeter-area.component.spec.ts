import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RectanglePerimeterAreaComponent } from './rectangle-perimeter-area.component';

describe('RectanglePerimeterAreaComponent', () => {
  let component: RectanglePerimeterAreaComponent;
  let fixture: ComponentFixture<RectanglePerimeterAreaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RectanglePerimeterAreaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RectanglePerimeterAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
