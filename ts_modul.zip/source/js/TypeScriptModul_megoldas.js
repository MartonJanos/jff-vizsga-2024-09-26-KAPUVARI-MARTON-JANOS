function isTextLong(text) {
    if (text.length >= 10) {
        return true;
    }
    else {
        return false;
    }
}
function getSquarePerimeter(a) {
    var perimeter = a * 4;
    return perimeter;
}
function countEven(numbers) {
    var evenCounter = 0;
    for (var i = 0; i < numbers.length; i++) {
        if (numbers[i] % 2 == 0) {
            evenCounter++;
        }
    }
    return evenCounter;
}
