function isTextLong(text: string): boolean {
    if (text.length >= 10) {
        return true;
    }
    else {
        return false;
    }
}

function getSquarePerimeter(a: number): number {
    let perimeter: number = a * 4;
    return perimeter;
}

function countEven(numbers: number[]): number {
    let evenCounter: number = 0;
    for (let i: number = 0; i < numbers.length; i++) {
        if (numbers[i] % 2 == 0) {
            evenCounter++;
        }
    }
    return evenCounter;
}